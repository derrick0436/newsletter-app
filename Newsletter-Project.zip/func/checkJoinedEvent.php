<?php
require('../inc/class/Event.php');
session_start();
if(isset($_SESSION["id"]) & isset($_SESSION["role"])){
    if($_SESSION["role"]=="member"){
            $event = new Event();
            echo json_encode(["result"=>"1","data"=>$event->checkJoinedEvent($_POST["id"]),"id"=>$_SESSION["id"]]);
    }
    else
    echo json_encode(["result"=>"0","id"=>$_SESSION["id"]]);
}
else
    echo json_encode(["result"=>"0","id"=>$_SESSION["id"]]);
?>