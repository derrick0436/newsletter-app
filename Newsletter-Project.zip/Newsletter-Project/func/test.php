<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 'On');
    require_once('../inc/class/DatabaseHandler.php');
    $db = DatabaseHandler::getInstance();
    $query= "INSERT INTO admin (username,pw) values(:uname,:pass)";    
    $parameters_query = [];
    $parameters_query[':uname'] = "admin";
    $parameters_query[':pass'] = password_hash("admin123",PASSWORD_DEFAULT);
    $result = $db->insert($query,$parameters_query);
    echo $result;
    
    // $query= "INSERT INTO member (stu_id,username,pw,email,block) values(:stu_id,:uname,:pass,:email,:block)";    
    // $parameters_query = [];
    // $parameters_query[':stu_id'] = "0191841";    
    // $parameters_query[':uname'] = "sinee";
    // $parameters_query[':pass'] = password_hash("sinee123",PASSWORD_DEFAULT);
    // $parameters_query[':email'] = "sinee@gmail.com";    
    // $parameters_query[':block'] = 0;    
    // $result = $db->insert($query,$parameters_query);
    // echo $result;    
    
// $login = new Login("0191691","derrick","derrick123","rickyuzuriha@gmail.com");
// echo $login->register();
// //echo $login->login("member"); 

// // $login = new Login(null,"admin","admin123",null);
// // echo $login->login("admin");     
?>